# Conversor OCR a formato de Crédito

Convierte el Excel de la herramienta OCR (hoja `Accounts`, exportación MMAS)
al diseño de `Output.xlsx`. No procesa imágenes/PDF ni realiza reconocimiento óptico.
El desarrollo se probó con los dos archivos proporcionados; otros proveedores o
versiones de plantilla requieren adaptar el esquema y validar las cuentas.

## Uso

1. Instalar Python 3.10 o posterior.
2. Instalar la dependencia: `pip install openpyxl`.
3. Colocar el código, el Excel OCR y la plantilla en una carpeta.
4. Ejecutar (una sola línea):

```bash
python ocr_a_credito.py --entrada "Exportadora de Hortalizas SA de CV_12_31_2025 (1).xlsx" --plantilla "Output.xlsx" --salida "Credito_nuevo.xlsx"
```

El archivo de salida debe ser nuevo. Los originales no se modifican. En Colab,
instalar con `%pip install openpyxl` y ejecutar el comando anteponiendo `!`.
También se puede importar:

```python
from ocr_a_credito import convert
reporte = convert("ocr.xlsx", "Output.xlsx", "Credito_nuevo.xlsx")
```

## Resultado

- Balance General y Estado de Resultados con diseño, fórmulas y estilos de la plantilla.
- Fecha exacta del OCR emparejada con B4, D4, F4, H4 o J4 de Balance General.
  Para nuevas fechas, ajustar previamente esos encabezados en una copia de la plantilla.
- Importes en miles de MXN con tres decimales para conservar precisión en pesos.
- Columnas de periodos no recibidos vacías: no se reutilizan los datos de ejemplo.
- Referencias entre las dos hojas convertidas a internas; no necesita el libro externo original.
- Conciliacion: 11 comprobaciones por periodo, calculadas en Python independientemente de Excel.
- Trazabilidad: cuenta, origen, destino, signo e importe; comentarios en celdas mapeadas.
- Revision: supuestos de clasificación y cuentas no mapeadas con saldo.
- Un archivo `.revision.json` para integración con procesos automáticos.

Excel debe recalcular las fórmulas al abrir. El programa fuerza recálculo automático,
pero openpyxl no calcula fórmulas ni escribe sus resultados almacenados. Un lector
que usa `data_only=True` mostrará valores vacíos en fórmulas hasta recalcular y guardar
con Excel. Los 22 controles del ejemplo sí se calcularon en Python.

## Criterios que requieren aprobación de Crédito

No reproduce mecánicamente los ajustes manuales del ejemplo: la herramienta ya
realizó una clasificación y no entrega el detalle original que justifica esos ajustes.
Una conciliación exacta acredita integridad aritmética, no clasificación correcta.

| Tema | Regla inicial |
|---|---|
| Unidades | Actual / Thousands / Millions se convierten a miles; sólo MXN. |
| Cuentas por cobrar | Código 1200 se trata como saldo neto; no se vuelve a restar la reserva 1300. |
| Partidas sin desglose | No se infiere IVA vs ISR, anticipos a proveedores ni composición de acreedores. |
| Depreciación acumulada | Código 2400 se presenta negativo. |
| Capital | Se conserva 5100; no se deducen aportaciones para futuros aumentos con base en el ejemplo. |
| Resultado acumulado | 5400+5410 menos utilidad neta del año; ésta se muestra por separado en fila 83. Revisar semántica del proveedor. |
| Resultado cambiario | 7000/7010 son ingresos/gastos no monetarios según sus etiquetas; se agrupan en otros ingresos/gastos, sin presumir que son cambiarios. |
| Participación trabajadores | 3700 a fila 57 y 3750 a sueldos; equivalencia provisional. |
| D&A | 6350+6600+6650; puede incluir deterioro si el origen no lo separa. |
| Datos ausentes | No se infieren dictaminador, Buró ni declaraciones fiscales. Categorías sin desglose se inicializan en cero; revisar notas. |

Las cuentas no mapeadas con saldo quedan señaladas. Saldos extraordinarios, nuevas
cuentas o reclasificaciones pueden producir diferencias: nunca se crea una partida
de ajuste para forzar el cuadre. Los importes vacíos en cuentas fuente requeridas,
fechas duplicadas, cuentas duplicadas y formatos numéricos inválidos detienen el proceso.

## Modificar el mapeo

Las constantes BG y ER relacionan fila destino con `{codigo: coeficiente}`.
Se puede reemplazar una regla sin editar Python con `--mapeo mapeo.json`.
Ejemplo de estructura, que mantiene las reglas actuales para efectivo e intereses:

```json
{
  "Bal. Gral.": {"9": {"1050": 1, "1100": 1, "1150": 1}},
  "Edo. Res.": {"16": {"6850": 1, "6870": 1, "6880": 1}}
}
```

Cada fila proporcionada REEMPLAZA su regla completa. Al mover una cuenta entre
filas se debe retirarla de la anterior para evitar duplicación; revisar conciliación.
Las reglas especiales de resultado del año (BG 81/83) están en `convert`.
Las filas sin conceptos mapeados son cero provisional, no afirmación de saldo inexistente.

El programa devuelve código 0 si concilia, 2 si genera salida con diferencias y 1
si no puede procesar. Incluso con código 0 debe revisarse la hoja Revision.

## Validación del ejemplo

| Concepto (miles MXN) | 2024 | 2025 |
|---|---:|---:|
| Activo | 565,298.663 | 595,590.653 |
| Pasivo | 214,175.630 | 232,171.403 |
| Capital | 351,123.033 | 363,419.250 |
| Utilidad neta | -13,698.499 | 1,307.161 |

22 controles conciliados dentro de 0.001 miles MXN (un peso). Se verificó además
limpieza de periodos no recibidos, eliminación de referencias externas en fórmulas,
rechazo de cuentas duplicadas y manejo de importes inválidos. Los archivos de entrada
originales no están incluidos en este paquete: utiliza los adjuntos de la conversación.
