#!/usr/bin/env python3
"""Convierte exportaciones Accounts (MMAS) al formato Output.xlsx de Crédito.

Python >=3.10; pip install openpyxl
No ejecuta OCR: transforma el Excel ya clasificado por la herramienta.
Ver README.md antes de aprobar las reclasificaciones propuestas.
"""
from __future__ import annotations
import argparse
import json
import math
import re
from datetime import datetime, date
from pathlib import Path
from decimal import Decimal, InvalidOperation
import openpyxl
from openpyxl.cell.cell import MergedCell
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.workbook.properties import CalcProperties
from openpyxl.utils import get_column_letter

# Código: coeficiente. Sólo cuentas de detalle, nunca subtotal + sus hijos.
BG = {
 9: {'1050':1,'1100':1,'1150':1}, 10:{'1200':1},
 11:{'1250':1}, 12:{'1400':1,'1450':1,'1500':1,'1550':1,'1600':1},
 13:{'1230':1,'1240':1}, 15:{'1700':1}, 17:{'1790':1},
 21:{'1670':1,'1680':1}, 24:{'1650':1,'1350':1,'1800':1},
 29:{'2050':1,'2100':1},30:{'2150':1},31:{'2300':1},32:{'2200':1},
 33:{'2070':1,'2250':1,'2350':1,'2360':1},34:{'2400':-1},
 40:{'2650':1,'2850':1,'2900':1,'2820':-1},
 42:{'2550':1},43:{'2700':1},
 44:{'2450':1,'2500':1,'2530':1,'2560':1,'2580':1,'2600':1,'2800':1,'2740':1,'2750':1},
 49:{'3400':1},50:{'3070':1,'3100':1},51:{'3500':1},
 52:{'3450':1,'3460':1},53:{'9951':1,'3900':1,'3920':1},
 54:{'3200':1,'3250':1,'3300':1,'3350':1},
 56:{'3550':1,'3750':1},57:{'3700':1},58:{'3850':1},59:{'3150':1},
 60:{'3050':1,'3360':1,'3370':1,'3600':1,'3650':1,'3800':1,'3910':1,'3960':1,'3965':1,'3970':1,'3940':1,'3950':1},
 65:{'4050':1,'4100':1,'4150':1,'4200':1,'4210':1},
 66:{'9952':1,'4400':1,'4250':1,'4300':1,'4340':1,'4345':1,'4350':1,'4600':1,'4660':1,'4680':1,'4700':1,'4800':1},
 68:{'4390':1},69:{'4450':1},70:{'4220':1,'4230':1,'4330':1},
 76:{'5050':1,'5100':1,'5150':1},77:{'5160':1},
 80:{'4650':1,'4670':1,'4690':1,'4750':1,'4850':1,'5180':1,'5190':1,'5420':1,'5450':-1},
 81:{'5400':1,'5410':1},84:{'5170':1},
}
ER = {
 7:{'6050':1,'6150':-1,'6200':-1},8:{'6250':1,'6350':1},
 12:{'6420':1,'6450':1,'6470':1,'6490':1,'6500':1,'6550':1,'6560':1,'6565':1,'6570':1,'6600':1,'6620':1,'6650':1,'6580':1,'6700':1,'6750':1,'7530':1,'6400':-1},
 16:{'6850':1,'6870':1,'6880':1},17:{'6800':1},
 23:{'6900':1,'7000':1,'7010':-1,'7040':1,'9953':1,'7050':1,'7090':-1,'9954':-1,'7100':-1,'7120':-1,'7150':1},
 27:{'7250':1,'7320':-1},28:{'7300':1},
 37:{'7230':-1},52:{'6350':1,'6600':1,'6650':1},
}
BG_INPUTS = list(range(9,25))+list(range(29,36))+list(range(40,46))+list(range(49,62))+list(range(65,71))+list(range(76,85))
ER_INPUTS = [7,8,12,16,17,18,19,23,27,28,29,33,37,38,41,42,43,52]
PERIOD_COLS = [2,4,6,8,10,18,20]

def number(value):
    """Números en convención MX/US: coma de miles y punto decimal.
    Vacío NO equivale a cero. Valores ambiguos o inválidos detienen el proceso.
    """
    if value is None or value == '':
        raise ValueError('Importe vacío; confirmar en origen, no sustituir por cero.')
    if isinstance(value, bool):
        raise ValueError('Un booleano no es un importe.')
    if isinstance(value, (float,int)):
        if not math.isfinite(value): raise ValueError('Importe no finito')
        return Decimal(str(value))
    t=str(value).strip().replace('\u00a0','').replace(' ','')
    t=re.sub(r'^(MXN|USD|\$)', '', t, flags=re.I)
    if t in ('-','—','–'): return Decimal(0)
    if t.startswith('(') and t.endswith(')'): t='-'+t[1:-1]
    if not re.fullmatch(r'[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?',t):
        raise ValueError(f'Importe no reconocido: {value!r}')
    return Decimal(t.replace(',',''))

def as_date(value):
    if isinstance(value, datetime): return value.date()
    if isinstance(value, date): return value
    for fmt in ('%m/%d/%Y','%Y-%m-%d','%d/%m/%Y'):
        try: return datetime.strptime(str(value).strip(),fmt).date()
        except ValueError: pass
    raise ValueError(f'Fecha no reconocida: {value!r}')

def read_source(path):
    w=openpyxl.load_workbook(path,data_only=True)
    if 'Accounts' not in w: raise ValueError('Se requiere la hoja Accounts.')
    s=w['Accounts']
    if s['B6'].value != 'Statement Date': raise ValueError('Encabezado OCR distinto del formato soportado.')
    periods={}
    for col in range(3,s.max_column+1):
        if s.cell(6,col).value is None: continue
        dt=as_date(s.cell(6,col).value)
        if dt in periods: raise ValueError(f'Fecha duplicada: {dt}')
        if s.cell(39,col).value != 'MXN': raise ValueError('Sólo se soporta MXN; no se aplica conversión cambiaria.')
        units=str(s.cell(38,col).value).strip().lower()
        factors={'actual':1,'thousands':1000,'millions':1000000}
        if units not in factors: raise ValueError(f'Unidad no soportada: {units}')
        entries={}; section=None
        for row in range(45,s.max_row+1):
            label=str(s.cell(row,2).value or '').strip()
            if label in ('Balance Sheet','Income Statement','Cash Flow'): section=label
            code=str(s.cell(row,1).value or '').strip()
            if section not in ('Balance Sheet','Income Statement') or not code: continue
            if code.endswith('.0'): code=code[:-2]
            key=(section,code)
            if key in entries: raise ValueError(f'Cuenta duplicada en {section}: {code}')
            try: val=number(s.cell(row,col).value)*factors[units]/Decimal(1000)
            except ValueError as ex: raise ValueError(f'{s.title}!{get_column_letter(col)}{row}: {ex}') from ex
            entries[key]=(val,label,f'Accounts!{get_column_letter(col)}{row}')
        periods[dt]={'entries':entries,'months':int(number(s.cell(7,col).value))}
    if not periods: raise ValueError('No se encontraron periodos.')
    return str(s['B1'].value), periods

def convert(entrada, plantilla, salida, config=None):
    entrada,plantilla,salida=map(Path,(entrada,plantilla,salida))
    if salida.resolve() in (entrada.resolve(),plantilla.resolve()): raise ValueError('La salida debe ser un archivo nuevo.')
    if salida.exists(): raise FileExistsError(f'La salida ya existe: {salida}')
    company,periods=read_source(entrada)
    w=openpyxl.load_workbook(plantilla,keep_links=False)
    for name in ('Bal. Gral.','Edo. Res.'):
        if name not in w: raise ValueError(f'Falta hoja {name}')
    bg,er=w['Bal. Gral.'],w['Edo. Res.']
    if bg['A46'].value!='ACTIVO TOTAL' or er['A7'].value!='Ventas Netas':
        raise ValueError('La versión de la plantilla no coincide con el esquema soportado.')
    mapping={'Bal. Gral.':BG,'Edo. Res.':ER}
    if config:
        for sh, rules in json.loads(Path(config).read_text(encoding='utf-8')).items():
            if sh not in mapping: raise ValueError(f'Hoja no permitida: {sh}')
            mapping[sh]=dict(mapping[sh])
            for r,terms in rules.items():
                if int(r) not in (BG_INPUTS if sh=='Bal. Gral.' else ER_INPUTS): raise ValueError(f'Fila no editable: {sh}!{r}')
                mapping[sh][int(r)]={str(k):Decimal(str(v)) for k,v in terms.items()}
    dates={as_date(bg.cell(4,c).value):c for c in PERIOD_COLS[:5] if isinstance(bg.cell(4,c).value,(datetime,date))}
    if set(periods)-set(dates): raise ValueError('Hay fechas sin columna en la plantilla. Ajuste las fechas de B4,D4,F4,H4,J4 antes de ejecutar.')
    active={dates[d] for d in periods}
    # Limpiar datos de otras empresas/periodos; conservar estilos y estructura.
    for s in (bg,er):
        for row in s:
            for cell in row:
                if isinstance(cell,MergedCell): continue
                cell.comment=None
                if isinstance(cell.value,str) and cell.value.startswith('='):
                    cell.value=cell.value.replace('[1]','')
        for c in PERIOD_COLS:
            if c not in active:
                for row in s.iter_rows(min_row=4,max_col=c+1,min_col=c):
                    for cell in row:
                        if not isinstance(cell,MergedCell): cell.value=None
        s['A1']=company
    bg['O2']=None; bg['O1']=None
    for a in ('M91','O91','M95','O95'): bg[a]=None
    # Eliminar comparaciones cuyo periodo no se recibió.
    for sh, specs in [(bg,[(13,4,6),(14,6,8),(15,8,10),(23,18,20)]),
                      (er,[(14,4,6),(15,6,8),(16,8,10),(24,18,20)])]:
        for c,left,right in specs:
            if left not in active or right not in active:
                for row in sh.iter_rows(min_row=4,max_row=90 if sh==bg else 57,min_col=c,max_col=c):
                    if not isinstance(row[0],MergedCell): row[0].value=None
    audit=[]; checks=[]; warnings=[]
    for dt,p in sorted(periods.items()):
        col=dates[dt]; letter=get_column_letter(col); entries=p['entries']
        def get(section,code):
            if (section,code) not in entries: raise ValueError(f'Falta cuenta requerida {section}/{code} para {dt}')
            return entries[(section,code)][0]
        values={}
        for sheet,section,inputs in [(bg,'Balance Sheet',BG_INPUTS),(er,'Income Statement',ER_INPUTS)]:
            for r in inputs:
                sheet.cell(r,col,0)
            vals={r:Decimal(0) for r in inputs}
            for r,terms in mapping[sheet.title].items():
                vals[r]=sum((get(section,k)*Decimal(str(coef)) for k,coef in terms.items()),Decimal(0))
                sources=[]
                for code,coef in terms.items():
                    v,label,origin=entries[(section,code)]
                    audit.append([str(dt),sheet.title,f'{letter}{r}',code,label,origin,float(v),float(coef),float(v*Decimal(str(coef)))])
                    sources.append(f'{code}: {origin} × {coef}')
                sheet.cell(r,col).comment=Comment('\n'.join(sources),'Conversor OCR')
            if sheet==bg:
                net=get('Income Statement','3300155')
                vals[83]=net
                # El capital fuente incluye resultado del año en 5400/5410.
                vals[81]-=net
                audit.append([str(dt),sheet.title,f'{letter}81 / {letter}83','3300155','Separar resultado del año del acumulado',entries[('Income Statement','3300155')][2],float(net),1,float(net)])
                for r in [81,83]: sheet.cell(r,col).comment=Comment('Capital: 5400 + 5410 menos utilidad neta = ejercicios anteriores; utilidad neta se presenta por separado. Confirmar clasificación contable.','Conversor OCR')
            for r,v in vals.items():
                sheet.cell(r,col,float(v)).number_format='#,##0.000;[Red](#,##0.000);–'
            values[sheet.title]=vals
        b,e=values['Bal. Gral.'],values['Edo. Res.']
        bg.cell(4,col,datetime.combine(dt,datetime.min.time()))
        bg.cell(5,col,'Por validar'); bg.cell(6,col,'Fuente OCR; dictaminador no informado')
        bg.cell(95,col).value=None
        if col-2 not in active:
            for r in (93,94): bg.cell(r,col).value=None
        er.cell(4,col,f"='Bal. Gral.'!{letter}4")
        er.cell(5,col,f"='Bal. Gral.'!{letter}5")
        # Restaurar referencias internas sin rangos sobre celdas combinadas.
        for r in (98,99,100,101,102,104,105,106,108,109,110,111):
            cell=bg.cell(r,col)
            if isinstance(cell.value,str) and cell.value.startswith('='):
                cell.value=cell.value.replace('O2',str(p['months']))
        er.cell(38,col,f'={letter}35+{letter}37')
        for r in (41,42,43): er.cell(r,col).value=None
        current=sum(b[r] for r in range(9,25)); fixed=sum(b[r] for r in range(29,36))
        assets=current+fixed+sum(b[r] for r in range(40,46))
        short=sum(b[r] for r in range(49,62)); long=sum(b[r] for r in range(65,71))
        equity=sum(b[r] for r in range(76,85))
        gross=e[7]-e[8]; op=gross-e[12]; pre=op-(e[16]-e[17]+e[18]+e[19])+e[23]
        profit=pre-e[27]-e[28]-e[29]+e[33]
        for label,actual,section,code in [
            ('Activo circulante',current,'Balance Sheet','3300244'),
            ('Activo fijo neto',fixed,'Balance Sheet','3300544'),
            ('Activo total',assets,'Balance Sheet','3300144'),
            ('Pasivo circulante',short,'Balance Sheet','3301144'),
            ('Pasivo LP',long,'Balance Sheet','3301344'),
            ('Capital',equity,'Balance Sheet','3301444'),
            ('Utilidad bruta',gross,'Income Statement','3300555'),
            ('Utilidad operativa',op,'Income Statement','3300455'),
            ('Resultado antes impuestos',pre,'Income Statement','3300355'),
            ('Resultado neto',profit,'Income Statement','3300155')]:
            source=get(section,code); diff=actual-source
            checks.append([str(dt),label,float(source),float(actual),float(diff),'OK' if abs(diff)<=Decimal('0.001') else 'REVISAR'])
        diff=assets-short-long-equity
        checks.append([str(dt),'Activo - pasivo - capital',0,float(diff),float(diff),'OK' if abs(diff)<=Decimal('0.001') else 'REVISAR'])
        used={(sec,code) for sh,sec in [('Bal. Gral.','Balance Sheet'),('Edo. Res.','Income Statement')] for terms in mapping[sh].values() for code in terms}
        for (section,code),(v,label,origin) in entries.items():
            if v and (section,code) not in used and not code.startswith(('330','220')):
                warnings.append([str(dt),'Cuenta no mapeada',f'{origin}: {code} {label} = {v} miles; verificar cobertura.'])
    notes=[
        'El OCR no permite replicar todas las reclasificaciones manuales del ejemplo. La conciliación no valida la clasificación.',
        'Sin desglose: 1250 se presenta en cuentas por cobrar, 1700 en pagos anticipados, 3500 en acreedores diversos; impuestos a favor no se separan en IVA/ISR.',
        '7000/7010 no identifican explícitamente resultado cambiario: se presentan como otros ingresos/gastos; no se presume su naturaleza.',
        '5100 se conserva en capital; no se infieren aportaciones para futuros aumentos ni se trasladan al pasivo.',
        '5400/5410 se agrupan y se separa la utilidad del año; confirmar esta convención con los estados financieros originales.',
        '3700 se asigna provisionalmente a participación de trabajadores; 3750 a sueldos. Confirmar naturaleza de ambas cuentas.',
        'La depreciación de resultados usa 6350+6600+6650; no usa cambio en depreciación acumulada. No separa deterioro incluido en 6350.',
        'Ceros sin cuenta asignada son categorías no desglosadas por el OCR, no evidencia de inexistencia. Buró, datos fiscales y dictamen no se infieren.',
        'Sólo se presentan periodos recibidos. Excel recalcula fórmulas al abrir; openpyxl no calcula ni guarda resultados de fórmulas.',
    ]
    warnings.extend(['Todos','Revisión de criterio',n] for n in notes)
    for name,headers,rows in [
        ('Conciliacion',['Fecha','Control','OCR (miles MXN)','Convertido (miles MXN)','Diferencia','Estado'],checks),
        ('Trazabilidad',['Fecha','Hoja destino','Celda destino','Código','Descripción OCR','Celda origen','Miles MXN','Coeficiente','Contribución'],audit),
        ('Revision',['Fecha','Tipo','Observación'],warnings)]:
        if name in w: del w[name]
        s=w.create_sheet(name); s.append(headers)
        for row in rows: s.append(row)
        s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
        for cell in s[1]: cell.font=Font(color='FFFFFF',bold=True);cell.fill=PatternFill('solid',fgColor='17365D')
        for c in range(1,len(headers)+1): s.column_dimensions[get_column_letter(c)].width=22 if c!=3 or name!='Revision' else 110
        for row in s.iter_rows(min_row=2):
            for cell in row:
                if isinstance(cell.value,float): cell.number_format='#,##0.000;[Red](#,##0.000)'
                cell.alignment=Alignment(vertical='top',wrap_text=True)
    w.calculation=CalcProperties(calcId=0,fullCalcOnLoad=True,forceFullCalc=True,calcMode='auto')
    # No quedan enlaces externos ni referencia a la carátula ausente.
    er['K2']="='Bal. Gral.'!A3"
    for s in w:
        for row in s:
            for cell in row:
                if cell.data_type=='f' and ('[' in cell.value or 'Carátula!' in cell.value):
                    raise ValueError(f'Referencia no resuelta: {s.title}!{cell.coordinate}')
    salida.parent.mkdir(parents=True,exist_ok=True)
    w.save(salida)
    report={'empresa':company,'unidad':'miles MXN','controles':checks,'advertencias':warnings}
    salida.with_suffix('.revision.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--entrada',required=True);p.add_argument('--plantilla',required=True)
    p.add_argument('--salida',required=True);p.add_argument('--mapeo',help='JSON opcional: reemplaza cuentas de filas específicas')
    a=p.parse_args()
    try: report=convert(a.entrada,a.plantilla,a.salida,a.mapeo)
    except (ValueError,OSError,InvalidOperation) as ex: p.exit(1,f'ERROR: {ex}\n')
    failures=sum(row[-1]!='OK' for row in report['controles'])
    print(f'Archivo generado: {a.salida}. Controles: {len(report["controles"])-failures} OK, {failures} por revisar.')
    print('Clasificaciones provisionales: consultar la hoja Revision antes de utilizar el resultado.')
    return 2 if failures else 0

if __name__=='__main__': raise SystemExit(main())
